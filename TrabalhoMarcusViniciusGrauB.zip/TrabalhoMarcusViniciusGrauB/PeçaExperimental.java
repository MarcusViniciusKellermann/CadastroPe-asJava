 

public class PeçaExperimental extends Peça {
    private int validade;

    public PeçaExperimental(int codigo, int categoria, int quant, String nome, double preco, int validade) {
        super(codigo, categoria, quant, nome, preco);
        this.validade = validade;
    }

    public int getValidade() {
        return validade;
    }

    public void setValidade(int validade) {
        this.validade = validade;
    }

    public String toString(){
        return "Peça Experimental=[Validade="+validade+" Codigo="+getCodigo()+" Categoria="+getCategoria()+" Quantidade="+getQuant()+" Nome="+getNome()+" Preço="+getPreco()+"]";
    }
}
