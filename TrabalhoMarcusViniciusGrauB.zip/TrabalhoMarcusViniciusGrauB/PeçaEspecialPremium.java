public class PeçaEspecialPremium extends PeçaEspecial {
    private double altura;
    private double peso;


    public PeçaEspecialPremium(String observacoes, String restricao, int codigo, int categoria, int quant, String nome, double preco, double altura, double peso) {
        super(observacoes, restricao, codigo, categoria, quant, nome, preco);
        this.altura = altura;
        this.peso = peso;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public String toString(){
        return "Peça Especial Premium=[Altura="+altura+" Peso="+peso+" Observaçoes="+getObservacoes()+" Restriçao="+getRestricao()+" Codigo="+getCodigo()+" Categoria="+getCategoria()+" Quantidade="+getQuant()+" Nome="+getNome()+" Preço="+getPreco()+"]";
    }

}