 

public class Teste {

    public static void main(String[] args) {
        Cadastro c = new Cadastro(2,10);
        Teclado t=new Teclado();
        int op=0;
        while(op!=9){
            int opc=t.leInt("\nDigite 1 para criar uma Peça, 2 para criar uma Peça Especial, 3 uma Peça Experimental , 4 uma Peça especial Premium, 5 para mostrar a peça,6 para remover uma peça, 7 para vender uma peça e 8 para mostrar relatorio de vendas ");
            if(opc==1){

                int codigo = t.leInt("\nDigite o codigo da peça ");
                int categoria = t.leInt("\nDigite a categoria da peça ");
                int quantidade = t.leInt("\nDigite a quantidade  da peça ");
                String nome = t.leString("\nDigite o nome da peça ");
                double preço = t.leDouble("\nDigite o preço da peça ");
                Peça p=new  Peça(codigo, categoria, quantidade, nome, preço);
            if(codigo<0){
                System.out.printf("Codigo negativo");
                break;
            
            }else if(categoria <1){
                System.out.printf("Categoria invalida");
                break;    
            }else if(categoria>20){
                System.out.printf("Categoria invalida");
                break;
            }else if(quantidade<0){
                System.out.printf("Quantidade negativa");
                break;   
            }else if(preço<0){
                System.out.printf("Preço negativo");
                break;   
            }else if(c.veriCod(p.getCodigo(),p.getNome())==true){
                     System.out.printf("\nErro");
            }else{
                    c.insere(p);
            }

                
            }else if(opc==2){
                int codigo=t.leInt("\nDigite o codigo da peça ");
                int categoria=t.leInt("\nDigite a categoria da peça ");
                int quantidade=t.leInt("\nDigite a quantidade  da peça ");
                String nome=t.leString("\nDigite o nome da peça ");
                double preço=t.leDouble("\nDigite o preço da peça ");
                String obs=t.leString("\nDigite uma observaçao sobre a peça ");
                String rest=t.leString("\nDigite uma restriçao sobre a peça ");
                PeçaEspecial p=new PeçaEspecial(obs,rest,codigo,categoria,quantidade,nome,preço);
                if(codigo<0){
                System.out.printf("Codigo negativo");
                break;  
                }else if(categoria <1){
                System.out.printf("Categoria invalida");
                break;    
                }else if(categoria>20){
                System.out.printf("Categoria invalida");
                break;
                }else if(quantidade<0){
                System.out.printf("Quantidade negativa");
                break;   
                }else if(preço<0){
                System.out.printf("Preço negativo");
                break;   
                }else if(c.veriCod(p.getCodigo(),p.getNome())==true){
                     System.out.printf("\nErro");
                }else{
                    c.insere(p);
                }

            }else if(opc==3){
                int codigo=t.leInt("\nDigite o codigo da peça ");
                int categoria=t.leInt("\nDigite a categoria da peça ");
                int quantidade=t.leInt("\nDigite a quantidade  da peça ");
                String nome=t.leString("\nDigite o nome da peça ");
                double preço=t.leDouble("\nDigite o preço da peça ");
                int validade=t.leInt("\nDigite a validade  da peça ");
                PeçaExperimental p= new PeçaExperimental(codigo,categoria,quantidade,nome,preço,validade);
                if(codigo<0){
                 System.out.printf("Codigo negativo");
                 break;  
                }else if(categoria <1){
                 System.out.printf("Categoria invalida");
                 break;    
                }else if(categoria>20){
                 System.out.printf("Categoria invalida");
                 break;
                }else if(quantidade<0){
                 System.out.printf("Quantidade negativa");
                 break;   
                }else if(preço<0){
                 System.out.printf("Preço negativo");
                 break;   
                }else if(c.veriCod(p.getCodigo(),p.getNome())==true){
                     System.out.printf("\nErro");
                }else{
                    c.insere(p);
                }
            }else if(opc==4){
                int codigo=t.leInt("\nDigite o codigo da peça ");
                int categoria=t.leInt("\nDigite a categoria da peça ");
                int quantidade=t.leInt("\nDigite a quantidade  da peça ");
                String nome=t.leString("\nDigite o nome da peça ");
                double preço=t.leDouble("\nDigite o preço da peça ");
                String obs=t.leString("\nDigite uma observaçao sobre a peça ");
                String rest=t.leString("\nDigite uma restriçao sobre a peça ");
                double altura=t.leDouble("\nDigite a altura da peça ");
                double peso=t.leDouble("\nDigite o peso da peça ");
                PeçaEspecialPremium p= new PeçaEspecialPremium(obs,rest,codigo,categoria,quantidade,nome,preço,altura,peso);
                
                if(codigo<0){
                System.out.printf("Codigo negativo");
                break;  
                }else if(categoria <1){
                System.out.printf("Categoria invalida");
                break;    
                }else if(categoria>20){
                System.out.printf("Categoria invalida");
                break;
                }else if(quantidade<0){
                System.out.printf("Quantidade negativa");
                break;   
                }else if(preço<0){
                System.out.printf("Preço negativo");
                break;   
                }else if(c.veriCod(p.getCodigo(),p.getNome())==true){
                     System.out.printf("\nErro");
                }else{
                    c.insere(p);
                }

            }else if(opc==5){
                c.mostra();
            }else if(opc==6){
                int opcc=t.leInt("Digite 1 para remover uma Peça apartir do nome, 2 apartir do codigo ou 3 para remover por categoria");
                if(opcc==1) {
                    String nome = t.leString("\nDigite o nome da peça ");
                    c.removePeca(nome);
                }else if(opcc==2){
                    int codigo=t.leInt("\nDigite o codigo da peça ");
                    c.removePecaCod(codigo);
                }else if(opcc==3){
                    int categoria=t.leInt("\nDigite a categoria da peça ");
                    c.removePecaCat(categoria);
                }else{
                    System.out.printf("Opçao Errada");
                }
            }else if(opc==7){
                c.vendePeça();
            }else if(opc==8){
                c.relatorioVendas();
            }else{
                break;
            }
        }


    }
}

