public class Peça {
    private int codigo,categoria,quant;
    private String nome;
    private double preco;

    public Peça(int codigo, int categoria, int quant, String nome, double preco) {
        this.codigo = codigo;
        this.categoria = categoria;
        this.quant = quant;
        this.nome = nome;
        this.preco = preco;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public int getCategoria() {
        return categoria;
    }

    public void setCategoria(int categoria) {
        this.categoria = categoria;
    }

    public int getQuant() {
        return quant;
    }

    public void setQuant(int quant) {
        this.quant = quant;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String toString(){
        return "Peça=[Codigo="+codigo+" Categoria="+categoria+" Quantidade="+quant+" Nome="+nome+" Preço="+preco+"]";
    }
}
