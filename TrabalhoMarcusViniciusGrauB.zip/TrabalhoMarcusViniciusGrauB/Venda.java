 

public class Venda {
    private String nomeven;
    private int quantidade,cod;
    private double valortotal;

    public Venda(String nomeven,int quantidade, int cod, double valortotal) {
        this.nomeven=nomeven;
        this.quantidade = quantidade;
        this.cod = cod;
        this.valortotal = valortotal;
    }

    public String getNomeven() {
        return nomeven;
    }

    public void setNomeven(String nomeven) {
        this.nomeven = nomeven;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public double getValortotal() {
        return valortotal;
    }

    public void setValortotal(double valortotal) {
        this.valortotal = valortotal;
    }

    public String toString(){
        return "Venda=[Nome da Venda="+nomeven+" Quantidade vendida="+quantidade+" Codigo da venda="+cod+" Valor total de venda="+valortotal+"]";
    }
}

