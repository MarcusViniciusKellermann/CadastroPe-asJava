 

public class PeçaEspecial extends Peça {

    private String observacoes;
    private String restricao;

    public PeçaEspecial(String observacoes,String restricao,int codigo, int categoria, int quant, String nome, double preco) {
        super(codigo, categoria, quant, nome, preco);
        this.observacoes=observacoes;
        this.restricao=restricao;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public String getRestricao() {
        return restricao;
    }

    public void setRestricao(String restricao) {
        this.restricao = restricao;
    }

    public String toString(){
        return "Peça Especial=[Observaçoes="+observacoes+" Restriçoes="+restricao+" Codigo="+getCodigo()+" Categoria="+getCategoria()+" Quantidade="+getQuant()+" Nome="+getNome()+" Preço="+getPreco()+"]";
    }

}
