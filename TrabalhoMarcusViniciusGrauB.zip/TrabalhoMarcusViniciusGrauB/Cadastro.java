public class Cadastro {
    private Peça [] cadP;
    private int total;
    private int totalvendas;
    private Venda[] arrayvenda;

    public Cadastro(int tamanho,int quantmaxvendas) {
        this.cadP = new Peça[tamanho];
        this.arrayvenda=new Venda[quantmaxvendas];
        total = 0;
    }

    public void insere(Peça p) {
        if (total < cadP.length) {
            cadP[total] = p;
            total++;

        }else {
            System.out.println(" Cadastro cheio...");
        }
    }

    public void inserevenda(Venda v ) {
        if (total < arrayvenda.length) {
            arrayvenda[totalvendas] = v;
            totalvendas++;

        } else {
            System.out.println("Total de Vendas...");

        }
    }

    public boolean veriCod(int codigo,String nome){
        for(Peça p: cadP){
            if(p!=null){
                if(p.getCodigo() == codigo){
                    System.out.printf("Esse codigo ja Existe ");
                    return true;
                }else if (p.getNome().equalsIgnoreCase(nome)){
                    System.out.printf(" Esse nome ja Existe");
                    return true;
                }
            }

        }
        return false;
    }
    

    public void mostra() {
        if (total == 0) {
            System.out.println("Cadastro vazio...");
        } else {
            Teclado t=new Teclado();
            int op=t.leInt("Digite 1 para mostrar todo cadastro ou 2 para mostrar apartir de campo numerico");
            if(op==1){
                for (int i = 0; i < total; i++) {
                    System.out.println(cadP[i]);
                }

            }else if (op==2){
                double limite=t.leDouble("Digite o limite de preço da peça ");
                double maximo=t.leDouble("Digite o maximo de preço da peça ");
                for(int i=0;i<total; i++){
                    if (cadP[i].getPreco()>=limite && cadP[i].getPreco()<=maximo){
                        System.out.println(cadP[i]);
                        break;
                    }
                }
            }
        }
    }

    public boolean remPe(int pos) {
        if (pos >= 0 && pos < total) {
            cadP[pos] = cadP[total - 1];
            total--;
            System.out.println("removeu!");
            return true;
        } else {
            return false;
        }
    }


    public void removePeca(String nome) {
        for (int i = 0; i < cadP.length; i++) {
            if (cadP[i].getNome().equalsIgnoreCase(nome)) {
              remPe(i);
                break;
            }
        }
    }

    public void removePecaCod(int codigo) {
        for (int i = 0; i < cadP.length; i++) {
            if (cadP[i].getCodigo()==codigo) {

                remPe(i);
                break;
            }
        }
    }

    public void removePecaCat(int categoria) {
        for (int i = 0; i < cadP.length; i++) {
            if (cadP[i].getCategoria()==categoria) {

                remPe(i);
                break;

            }
        }
    }



    public Peça getPecaNome(String nome){
        for(Peça b : cadP){
            if(b.getNome().equalsIgnoreCase(nome)){
                return b;
            }
        }
        return null;
    }

    public Peça getPecaCodigo(int codigo){
        for(Peça a : cadP){
            if(a.getCodigo()==codigo){
                return a;
            }
        }
        return null;
    }

    public void vendePeça(){
        Teclado t =new Teclado();
        int op=t.leInt("Digite 1 se voce quer vender a peça apartir do nome ou 2 apartir do codigo");
        if(op==1){
            String nome=t.leString("Digite o nome da peça");
            Peça p=getPecaNome(nome);
            if(p==null){
                System.out.printf("Erros");

            }else{
                int quantpe=t.leInt("Digite quantas Peças voce quer vender ");
                if(p.getQuant()<quantpe){
                    System.out.printf("Erro peça insuficiente");

                }else{
                    int novaQuant=p.getQuant()-quantpe;

                    double valorTotal=p.getPreco()*quantpe;

                    p.setQuant(novaQuant);

                    Venda ve=new Venda(p.getNome(),quantpe,p.getCodigo(),valorTotal);

                    inserevenda(ve);


                }
            }


        }else if(op==2){
            int codigo=t.leInt("Digite o codigo da Peça");
            Peça p=getPecaCodigo(codigo);
            if(p==null){
                System.out.printf("Erros");
            }else{
                int quantpe=t.leInt("Digite quantas Peças voce quer vender ");
                if(p.getQuant()<quantpe){
                    System.out.printf("Erro peça insuficiente");

                }else{

                    int novaQuant=p.getQuant()-quantpe;
                    p.setQuant(novaQuant);

                    double valorTotal=p.getPreco()*quantpe;

                    p.setQuant(novaQuant);

                    Venda ve=new Venda(p.getNome(),quantpe,p.getCodigo(),valorTotal);

                    inserevenda(ve);

                }
            }

        }

    }

    public void relatorioVendas(){
        for (int i = 0; i < totalvendas; i++) {
            System.out.println(arrayvenda[i]);

        }

    }


}

